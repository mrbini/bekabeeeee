# live-build configuration for Kali ISO images

Have a look at https://docs.kali.org/development/live-build-a-custom-kali-iso
for explanations on how to use this repository.
